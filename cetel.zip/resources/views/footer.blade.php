<footer class="blue darken-4 page-footer">
    <div class="footer-copyright">
      <div class="row container">
        <div class="col s6 left-align">
          <font class=""> © {{ date("Y"); }} CETEL - Centro de Estudos Teológicos Logos </font>
        </div>
        <div class="col s6 right-align">
          <font>Site Desenvolvido por: <a class="grey-text text-lighten-4" href="http://www.instagram.com/cintratechcrafting"> Cintra Tech Crafting</a> </font>
        </div>
      </div>
    </div>
  </footer>
  