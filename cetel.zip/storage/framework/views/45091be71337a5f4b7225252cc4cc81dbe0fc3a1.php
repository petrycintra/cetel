<nav class="blue darken-4 hide-on-med-and-down">
    <div class="nav-wrapper container">
      <ul id="nav-mobile" class="left">
        <li><a href=""><i class="material-icons left">alternate_email</i> seucontato@dominio.com </a></li>
        <li><a href=""><i class="material-icons left">phone</i> (73) 9 8888-8888 | (73) 9 8888-8888 </a></li>
      </ul>

      <ul id="nav-mobile" class="right">
        <li><a href=""> Curso Presencial </a></li>
        <li><a href="<?php echo e(Route('login.form')); ?>" class="orange  valign-wrapper"> Realizar Login </a></li>
      </ul>
      </div>
</nav>

<nav class="white hide-on-med-and-down">
    <div class="nav-wrapper container">
        <img href="#" class="left brand-logo" id="logo" src="/img/logo-index.png">
      <ul id="nav-mobile" class="right">
        <li ><a class="black-text" href=""> Inicio </a></li>
        <li><a class="black-text" href=""> Quem Somos </a></li>
        <li ><a class="black-text" href=""> Docentes </a></li>
        <li><a class="black-text" href=""> FAQ </a></li>
        <li><a class="black-text" href=""> Contato </a></li>
      </ul>
      </div>
</nav>

<nav class="blue darken-4 hide-on-large-only">
  <div class="nav-wrapper container">
      <img href="#" class="left brand-logo" id="logo" src="/img/logo.png">
    <ul id="nav-mobile" class="right">
      <li><a href="#" data-target="slide-out-mobile" class="sidenav-trigger right hide-on-large-onyl"><i class="material-icons left">menu</i></a></li>
    </ul>
    </div>
</nav>
<?php /**PATH C:\laragon\www\speb\resources\views/navbar_index.blade.php ENDPATH**/ ?>