<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?php echo $__env->yieldContent('title'); ?></title>

    <!-- Importar CSS do framework Materialize -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">

    <!-- Importar Icones do framework Materilize -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">

    <!-- Importar CSS personalizado manualmente -->
    <link rel="stylesheet" type="text/css" href="./css/layout.css" media="screen" />

</head>
<body>

    <?php echo $__env->yieldContent('navbar'); ?>
    <?php echo $__env->yieldContent('body'); ?>

    
</body>

<main></main>

    <!-- Importar JavaScript básico do materialize -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>

    <!-- Importar framework Vue.js -->
    <script src="https://unpkg.com/vue@3/dist/vue.global.js"></script>

    <!-- Importar JavaScript personalizado manualmente -->
    <script src="./js/layout.js"></script>

    <?php echo $__env->yieldContent('js'); ?>


</html>


<?php echo $__env->yieldContent('css'); ?>
<?php $__currentLoopData = $index; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dados): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<style>


/* Div com as informações sobre a escola */
.about{
    background: url("../img/<?php echo e($dados->about_photo); ?>");
    background-size: 100%;
    background-position: center;
    background-repeat: no-repeat;
    margin-top: 10%;
}

.about-mobile{
    background: url("../img/<?php echo e($dados->about_photo); ?>");
    background-size: 100%;
    background-position: center;
    background-repeat: no-repeat;
}

/* div com nova chamada para a inscrição/matricula */
.about_two{
    background: url("../img/<?php echo e($dados->about_footer_photo); ?> ");
    background-size: 100%;
    background-position: center;
    background-repeat: no-repeat;
    text-align: justify;
}

</style>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<script></script>

<?php /**PATH C:\laragon\www\cetel\resources\views/layout.blade.php ENDPATH**/ ?>