
                                              <!-- Importar configurações do Framework Front-End Materialize.Css -->
<?php $__env->startSection('title', 'CETEL - Centro de Estudos Teológicos Logos'); ?> <!-- Titulo da Página -->
<?php $__env->startSection('body'); ?>                                                <!-- Inicia a seção d conteúdo da página -->
                                        <!-- Importar configurações do menu superior -->

<?php if(auth()->guard()->check()): ?>
<meta http-equiv="refresh" content="0; URL='./dashboard'"/>
<?php else: ?>

<?php $__currentLoopData = $index; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dados): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<div class="content-login">
<!-- É aqui onde fica a imagem de fundo, adicionado via css -->
</div>

<div class="row white container login s12">

    <div class="row container center">

        <form action="<?php echo e(Route('login.auth')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            
            <br><br>
            <div class="row">
                <div class="input-field col s12">
                    <input id="email" name="email" placeholder="Insira seu E-mail" type="email" class="validate" required >
                    <label class="active" for="email"><i class="material-icons left">person</i> E-mail</label>
                </div>
            </div>

            <div class="row">
                <div class="input-field col s12">
                    <input id="password" name="password" placeholder="Insira sua senha" type="password" class="validate" required>
                    <label class="active" for="password"><i class="material-icons left">password</i> Senha </label>
                </div>
            </div>

            <button type="submit" class="btn blue darken-4"> FAZER LOGIN </button>
            <a href="" class="btn orange darken-4" disabled> CADASTRAR </a><br><br>
            <a href="" class="waves-effect waves-teal btn-flat" disabled>Esqueceu a senha?</a>

        </form>

    </div>

</div>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>

<?php if($mensagem = Session::get('success')): ?>
<button class="btn green darken-2 notificacao"><i class="material-icons left">check</i><?php echo e($mensagem); ?></button>
<?php endif; ?>

<?php if($mensagem = Session::get('erro')): ?>
<button class="btn orange darken-2 notificacao"><i class="material-icons left">check</i><?php echo e($mensagem); ?></button>
<?php endif; ?>

<?php endif; ?>

<?php echo $__env->make('navbar_login', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\cetel\resources\views/login.blade.php ENDPATH**/ ?>