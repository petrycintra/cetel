<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?php echo $__env->yieldContent('title'); ?></title>

    <!-- Importar CSS do framework Materialize -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">

    <!-- Importar Icones do framework Materilize -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">

</head>
<body>

    <?php echo $__env->yieldContent('navbar'); ?>
    <?php echo $__env->yieldContent('body'); ?>
    
</body>

    <!-- Importar JavaScript básico do materialize -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>

    <!-- Importar framework Vue.js -->
    <script src="https://unpkg.com/vue@3/dist/vue.global.js"></script>

    <?php echo $__env->yieldContent('js'); ?>



</html>

<?php echo $__env->yieldContent('css'); ?>

<style>

    body{
        background-color: rgb(76, 73, 71);
    }

    #step_by_step{
        height: 150px;

    }
    
</style>

<script>

    $(document).ready(function() {
    $('input#input_text, textarea#textarea2').characterCounter();
    });

</script><?php /**PATH C:\laragon\www\Nutrios\resources\views/layout.blade.php ENDPATH**/ ?>