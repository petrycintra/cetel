                                  <!-- Importar configurações do Framework Front-End Materialize.Css -->
<?php $__env->startSection('title', 'Nutrios - Nutrição e receitas'); ?>  <!-- Titulo da Página -->
<?php $__env->startSection('body'); ?>                                    <!-- Inicia a seção d conteúdo da página -->


<div class="row container">
    <div class="row container">
        <div class="row center">
            <div class="col s12 m12">
                <div class="card pink lighten-5">
                    <div class="card-content text">

                        <form action="">
                            <span class="card-title"><strong>LOGIN</strong></span><br>

                            <div class="row">
                                <div class="input-field col s12">
                                    <input id="email" placeholder="Insira seu E-mail" type="email" class="validate" required >
                                    <label class="active" for="email"><i class="material-icons left">person</i> E-mail</label>
                                </div>
                            </div>

                            <div class="row">
                                <div class="input-field col s12">
                                    <input id="password" placeholder="Insira sua senha" type="password" class="validate" required>
                                    <label class="active" for="password"><i class="material-icons left">password</i> Senha </label>
                                </div>
                            </div>

                            <a type="submit" class="btn pink lighten-2"> FAZER LOGIN </a>
                            <a href="" class="btn orange lighten-2"> CADASTRAR </a><br><br>
                            <a href="" class="waves-effect waves-teal btn-flat">Esqueceu a senha?</a>

                        </form>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('nav-and-sidebar'); ?>                         <!-- Inicia o seção de menu superior e lateral da página -->
                                  <!-- Importar configurações do menu superior -->
<?php $__env->stopSection(); ?>                                         <!-- Encerra a seção de menu superior e lateral da página -->
<?php echo $__env->make('navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Nutrios\resources\views/login.blade.php ENDPATH**/ ?>