
                                  <!-- Importar configurações do Framework Front-End Materialize.Css -->
<?php $__env->startSection('title', 'SPEB - Psicanalise'); ?>  <!-- Titulo da Página -->
<?php $__env->startSection('body'); ?>                                    <!-- Inicia a seção d conteúdo da página -->
                                  <!-- Importar configurações do menu superior -->


<div class="content">
    <div class="slider">

        <input class="radio-btn" type="radio" class="radio-slider" name="radio-slider" id="radio1">
        <input class="radio-btn" type="radio" class="radio-slider" name="radio-slider" id="radio2">
        <input class="radio-btn" type="radio" class="radio-slider" name="radio-slider" id="radio3">

        <div class="slide s1">
            <img src="/img/slide/1.jpg">
        </div>

        <div class="slide">
            <img src="/img/slide/2.jpg">
        </div>

        <div class="slide">
            <img src="/img/slide/3.jpg">
        </div>
    </div>

    <div class="cards">
        <div class="slide-text s1">
            <div class="card-image">
                <div class="card-content white-text">
                    <h2 class="card-title"> <strong>Curso Presencial</strong></h2>
                    <h5>Inscreva-se na proxima turma.</h5>
                </div>

                <div class="card-action"><br>
                    <a href="https://api.whatsapp.com/send?phone=5573981830090&text=Quero%20saber%20mais%20sobre%20o%20curso%20de%20Formação%20em%20Psicanálise%20da%20SPEB" class="btn white black-text"><strong>Quero me Inscrever</strong></a>
                </div>
            </div>
        </div>
    </div>
        
    <div class="navigation">
        <label class="bar b1" for="radio1" id="label1" ></label>
        <label class="bar b2" for="radio2" id="label2" ></label>
        <label class="bar b3" for="radio3" id="label3" ></label>
    </div>
    <div>
        
    </div>
</div>

<div class="row white container description s12">

    <div class="col s1 description-text s1">
        <div class="card-image">
            <div class="card-content black-text center-align">
                <br><i class="material-icons center">lightbulb</i><br>
            </div>
        </div>
    </div>

    <div class="col s2 description-text s1">
        <div class="card-image">
            <div class="card-content black-text valign-wrapper">
                <h6 class="card-title"> <strong>Livre Associação</strong><br> de Idéias </h6>
            </div>
        </div>
    </div>

    <div class="col s1 description-text s1">
        <div class="card-image">
            <div class="card-content black-text center-align">
                <br><i class="material-icons center">hotel</i><br>
            </div>
        </div>
    </div>

    <div class="col s2 description-text s1">
        <div class="card-image">
            <div class="card-content black-text valign-wrapper">
                <h6 class="card-title"> <strong>Interpretação</strong><br> dos Sonhos </h6>
            </div>
        </div>
    </div>

    <div class="col s1 description-text s1">
        <div class="card-image icon">
            <div class="card-content black-text center-align">
                <br><i class="material-icons center">sync_alt</i><br>
            </div>
        </div>
    </div>

    <div class="col s2 description-text s1">
        <div class="card-image">
            <div class="card-content black-text valign-wrapper">
                <h6 class="card-title"> <strong>Observação do</strong><br> Fenômeno da Transferência </h6>
            </div>
        </div>
    </div>

    <div class="col s1 description-text s1">
        <div class="card-image">
            <div class="card-content black-text center-align">
                <br><i class="material-icons center">psychology_alt</i><br>
            </div>
        </div>
    </div>

    <div class="col s2 description-text s1">
        <div class="card-image">
            <div class="card-content black-text valign-wrapper">
                <h6 class="card-title"> <strong>Analise dos</strong><br> Atos Falhos e da Resistência </h6>
            </div>
        </div>
    </div>

    <div class="col s6 card-image banner">
        <img class="bannerimg" src="img/slide/banner.png" alt="">
    </div>

    <div class="col s6 card-image banner">
        <img class="bannerimg" src="img/slide/banner2.png" alt="">
        <div class="card-content valign-wrapper">
            <h4 class="card-title description-inside white-text"> <strong>Matrículas Abertas</strong><br> </h4>
            <h6 class="card-title description-inside-sub orange-text"> <strong>Vagas abertas para a turma de janeiro de 2024</strong><br> </h6>
            <p class="card-title description-inside-subber white-text"> No Brasil e no Mundo a psicanálise é exercida livremente e não é uma profissão regulamentada.
                Sendo assim, é uma profissão livre, reconhecida pelo Ministério do Trabalho e Emprego.<br> </p>
            <a href="" class="card-title description-inside-btn white-text btn orange"> QUERO ME MATRICULAR HOJE </a>
        </div>
    </div>

</div>

    <div class="card about">
        <div class=" row container valign-wrapper">
            <div class="logo-about col s4">
                <img class="left brand-logo col s12" id="logo" src="/img/logo.png"><br><br><br><br>
                <span class="card-title col s4 orange-text col s12 center"><strong>Sobre Nossa escola</strong></span>
            </div>
            <div class="card-content col s8 white-text">
                <h6>Somos uma uma instituição científica, de direito privado, sem finalidade lucrativa, com sede na Praça Castro Alves, 83,
                    Centro, Itororó-BA, com foro no Cartório de Notas e Ofícios da mesma cidade,  destinada a congregar psicanalistas,
                    pesquisadores do psiquismo humano, formar psicanalistas clínicos e didáticos para o exercício da profissão,
                    realizar cursos de especialização e congressos nas suas respectivas áreas de interesse.</h6><br>

                <h6><strong>Nossa Missão:</strong> A Sociedade de Psicanálise Evolutiva do Brasil tem como missão zelar pela praxis
                    da psicanálise em âmbito nacional, assistir e supervisionar o exercício da prática psicanalítica dos seus membros,
                    promover estudos de formação em Psicanálise e ciências afins, bem como capacitar novos Psicanalistas em todo território
                    nacional para o exercício da profissão de acordo com as disposições legais em vigência, além de  proporcionar a
                    capacitação do profissional Psicanalista nos postulados das doutrinas Freudianas.</h6>
            </div>
        </div>
    </div>

    <div class="card">
        <div class="card-content"  href="#">
            <span class="card-title orange-text center"> <strong>Perguntas Frequentes</strong> </span>
        </div>
    </div><br>

    <div class="container white">
        <ul class="collapsible">
            <li>
              <div class="collapsible-header"><i class="material-icons">filter_drama</i>o que é Psicanálise?</div>
              <div class="collapsible-body"><span> É a ciência/arte que objetiva a transposição inconsciente/consciente.
                Considerada como a forma de tratamento das neuroses atualmente denominadas “psiconeuroses” tem por norma seu tratamento através de: <br><br>
                <ol>
                    <li> Processo de Livre Associação de Idéias; </li>
                    <li> Interpretação dos Sonhos; </li>
                    <li> Observação e Análise do fenômeno da Transferência; </li>
                    <li> Análise dos Atos Falhos (Parapraxias) e da Resistência. </li>
                </ol></span></div>
            </li>
            <li>
              <div class="collapsible-header"><i class="material-icons">place</i>Sua abrangência limita-se:</div>
              <div class="collapsible-body"><span>Ao método de investigação do inconsciente; À psicoterapia baseada nesse método e;
                Ao conjunto de teorias e normas em que são sistematizados os dados introduzidos pelo método psicanalítico.
                No dizer de Freud, “é uma profissão de pessoas leigas que curam almas, sem que necessariamente sejam médicos ou sacerdotes”.</span></div>
            </li>
            <li>
              <div class="collapsible-header"><i class="material-icons">whatshot</i>O curso tem registro no MEC?</div>
              <div class="collapsible-body"><span>Não. Nem tão pouco os demais cursos de formação em Psicanálise existentes no País. Inexistem, também,
                cursos de Psicanálise no âmbito universitário e sim Especialização Lato Sensu. Concluído, o psicanalista recebe um Certificado expedido pela Sociedade.
                No entanto, há sociedades que não emitem sequer uma comprovação de conclusão de curso. Nosso CENTRO cumpre a risca essa necessidade.</span></div>
            </li>
            <li>
                <div class="collapsible-header"><i class="material-icons">filter_drama</i>Quem é o psicanalista junto a clientela e ao ministério do Trabalho?</div>
                <div class="collapsible-body"><span>É um profissional que pratica a Psicanálise em consultórios, clínicas e até hospitais,
                    empregando metodologia exclusiva ao bom exercício da profissão, quais sejam, as técnicas e meios eficazes da psicanálise no tratamento das psiconeuroses.
                    Para atingir plenamente seus objetivos, o psicanalista deve ser uma pessoa com sólida formação humanitária,
                    visto que a profissão requer uma acentuada cumplicidade entre analista e seu paciente. Os psicanalistas têm sua profissão classificada na CBO
                    (Classificação Brasileira de Ocupações) no Ministério do Trabalho – Portaria nº 397/TEM de 09/10/2002, sob o nº 2515.50,
                    podendo exercer sua profissão em todo o Território Nacional.</span></div>
              </li>
              <li>
                <div class="collapsible-header"><i class="material-icons">place</i>Porque o curso é aberto a várias profissões?</div>
                <div class="collapsible-body"><span>É aberto porque nenhuma Lei especificou o contrário. Vale dizer, que desde o princípio era uma profissão aberta a
                    quem se interessasse e que atraiu não só médicos – como Jung e Adler – mas também advogados, filósofos, literatos, educadores e teólogos,
                    sociólogos e pedagogos. Por isso restringir a Psicanálise a essa ou àquela profissão é absolutamente contrário à ciência, ilegal e inconstitucional,
                    pois “todos são iguais perante a Lei”.</span></div>
              </li>
              <li>
                <div class="collapsible-header"><i class="material-icons">whatshot</i>O que regulamente a profissão psicanalista?</div>
                <div class="collapsible-body"><span>No Brasil e no Mundo a psicanálise é exercida livremente e não é uma profissão regulamentada. Sendo assim,
                    é uma profissão livre, reconhecida pelo Ministério do Trabalho e Emprego (CBO – código 2515.50), amparada pelo Decreto nº 2.208 de 17/04/1997,
                    que estabelece Diretrizes e Bases da Educação Nacional e pela Constituição Federal nos artigos 5º incisos II e XIII. Repisando: pode ser exercida
                    em todo o País.</span></div>
              </li>
              <li>
                <div class="collapsible-header"><i class="material-icons">filter_drama</i>O que faz o psicanalista?</div>
                <div class="collapsible-body"><span>Há uma grande necessidade de psicanalistas para orientar as pessoas na solução de seus problemas existenciais,
                    tais como: fobias, ansiedades, depressões, obsessões, impulsos auto e heteroagressivos, angústias e crises de toda ordem. O profissional de Psicanálise
                    ajudará a sociedade a ficar mais humana e a vida a ter mais sentido!</span></div>
              </li>
              <li>
                <div class="collapsible-header"><i class="material-icons">place</i>Quem poderá fazer o curso?</div>
                <div class="collapsible-body"><span>Médicos, Professores, Engenheiros, Odontólogos, Advogados, Assistentes Sociais, Pedagogos, Teólogos, Enfermeiros,
                    Pastores, Padres, Psicólogos, Contadores, etc. Este curso é dirigido a todos os interessados em adquirir conhecimentos mais profundos em Psicanálise.
                    Aos que querem aprender a dinâmica de seus problemas emocionais e afetivos de acordo com as teorias psicanalíticas, e aos que desejam dedicar-se à
                    Psicanálise como Terapeutas e Clinicar.</span></div>
              </li>
              <li>
                <div class="collapsible-header"><i class="material-icons">whatshot</i>Third</div>
                <div class="collapsible-body"><span>Oferecemos o curso on-line com encontros mensais na plataforma com dias e hora previamente marcados.
                    <br><br>Dispomos de turmas presencias. Consulte nossa coordenação pelos telefones disponibilizados abaixo.</span></div>
              </li>
              <li>
                <div class="collapsible-header"><i class="material-icons">filter_drama</i>Quais os requisitos?</div>
                <div class="collapsible-body"><span>Para matricular-se no Curso de Psicanálise Clínica o aluno deverá ter concluído um Curso Superior.</span></div>
              </li>
              <li>
                <div class="collapsible-header"><i class="material-icons">place</i>Grau conferido?</div>
                <div class="collapsible-body"><span>A SPEB conferirá o grau de Psicanalista Clínico. A SOPOB – Sociedade Psicanalítica Oficial do Brasil
                    credenciará o formando a exercer legalmente sua profissão.</span></div>
              </li>
              <li>
                <div class="collapsible-header"><i class="material-icons">whatshot</i>Qual a documentação exigida?</div>
                <div class="collapsible-body"><span>Cópia do Diploma ou Certificado do 3o Grau;
                    <br><br>Duas fotos 3/4;
                    <br><br>Cópia de Identidade e CPF;
                    <br><br>Comprovante de depósito bancário referente à primeira disciplina.</span></div>
              </li>
              <li>
                <div class="collapsible-header"><i class="material-icons">filter_drama</i>Qual o valor do investimento</div>
                <div class="collapsible-body"><span>O valor é de R$290,00 por módulo.</span></div>
              </li>
              <li>
                <div class="collapsible-header"><i class="material-icons">place</i>Qual a duração do curso</div>
                <div class="collapsible-body"><span>No intuito de uma melhor formação dos nossos alunos, a SPEB dispõe de 24 módulos, sendo um por mês com aula on-line
                    ou presencial, trabalhos extra aula, indicações de leituras e pesquisas. Assim o curso tem duração 2 anos.</span></div>
              </li>
              <li>
                <div class="collapsible-header"><i class="material-icons">whatshot</i>Análise Didata</div>
                <div class="collapsible-body"><span>Apresentar a Certidão de Análise Didata, assinada por um Psicanalista Clínico de sua cidade,
                    comprovando que fez no mínimo 30 (trinta) sessões analíticas.</span></div>
              </li>
              <li>
                <div class="collapsible-header"><i class="material-icons">filter_drama</i>Estágio</div>
                <div class="collapsible-body"><span>O aluno receberá da SPEB partir do 18º Módulo e Certidão de Análise Didata, uma autorização por escrito para
                    atender pacientes-piloto em sua cidade, tendo o acompanhamento de um Analista. A SPEB disponibilizará na ocasião o roteiro do Estágio.</span></div>
              </li>
              <li>
                <div class="collapsible-header"><i class="material-icons">place</i>Qual o Trabalho de Conclusão de Curso (TCC)?</div>
                <div class="collapsible-body"><span>O formando deverá apresentar até o final do Curso o seu TCC (Trabalho de Conclusão de Curso).
                    Este pode ser em forma de artigo, monografia, resumo ou estudo de casos.</span></div>
              </li>
              <li>
                <div class="collapsible-header"><i class="material-icons">whatshot</i>Nota mínima para aprovação</div>
                <div class="collapsible-body"><span>Exige-se nota mínima sete (7.0), para a aprovação.</span></div>
              </li>
          </ul>
    </div><br>

    <div class="card about_two">
        <div class=" row container valign-wrapper">
            <div class="logo-about col s6">
                <img class="left brand-logo col s12" id="logo" src="/img/logo.png"><br><br><br><br>
                <span class="card-title col s4 orange-text col s12 center"><strong>O curso chamou sua atenção?</strong></span>
            </div>
            <div class="card-content col s6 white-text">
                <h3> <strong>Curso Presencial</strong></h3>
                    <h5>Inscreva-se na proxima turma. e não deixe a oportunidade ir embora.</h5>

                    <div class="card-action"><br>
                        <a href="https://api.whatsapp.com/send?phone=5573981830090&text=Quero%20saber%20mais%20sobre%20o%20curso%20de%20Formação%20em%20Psicanálise%20da%20SPEB" class="btn orange black-text"><strong>MATRICULE-SE AGORA</strong></a>
                    </div>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('navbar_index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\speb\resources\views/index.blade.php ENDPATH**/ ?>