<nav class="blue darken-4 hide-on-med-and-down">
    <div class="nav-wrapper container">
        <img href="#" class="left brand-logo" id="logo" src="/img/logo.png">
      <ul id="nav-mobile" class="right">
        <li><a href=""><i class="material-icons left">alternate_email</i> seucontato@dominio.com </a></li>
        <li><a href=""><i class="material-icons left">phone</i> (73) 9 8888-8888 | (73) 9 8888-8888 </a></li>
        <li><a href="#" data-target="slide-out-desktop" class="sidenav-trigger right show-on-large"><i class="material-icons left">menu</i></a></li>
        
      </ul>
      </div>
</nav>

<nav class="blue darken-4 hide-on-large-only">
  <div class="nav-wrapper container">
      <img href="#" class="left brand-logo" id="logo" src="/img/logo.png">
    <ul id="nav-mobile" class="right">
      <li><a href="#" data-target="slide-out-mobile" class="sidenav-trigger right hide-on-large-onyl"><i class="material-icons left">menu</i></a></li>
    </ul>
    </div>
</nav>
<?php /**PATH C:\laragon\www\speb\resources\views/navbar.blade.php ENDPATH**/ ?>