<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?php echo $__env->yieldContent('title'); ?></title>

    <!-- Importar CSS do framework Materialize -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">

    <!-- Importar Icones do framework Materilize -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">

</head>
<body>

    <?php echo $__env->yieldContent('navbar'); ?>
    <?php echo $__env->yieldContent('body'); ?>
    
</body>

<main></main>

    <!-- Importar JavaScript básico do materialize -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>

    <!-- Importar framework Vue.js -->
    <script src="https://unpkg.com/vue@3/dist/vue.global.js"></script>

    <?php echo $__env->yieldContent('js'); ?>



</html>

<?php echo $__env->yieldContent('css'); ?>

<style>

    body{
        display: flex;
        min-height: 100vh;
        flex-direction: column;
        /* background-color: rgb(76, 73, 71); */
    }

    #logo{
        height: 60px;
        margin-top: 2px;
    }

    #step_by_step{
        height: 150px;
    }

    main {
    flex: 1 0 auto;
    }

    /** 
    **/

    .content{
        height: 520px;
        width: 100%;
        overflow: hidden;
        position: relative;
    }
	
	.navigation{
        position: absolute;
        bottom: 75px;
        left: 50%;
        transform: translate(-50%);
        cursor: pointer;
        display: flex;
    }

    .cards{
        position: absolute;
        bottom: 225px;
        left: 5%;
        cursor: pointer;
        display: flex;
    }
	
	.bar{
        width: 70px;
        height: 17px;
        border: 2px solid #fff;
        border-radius: 5px;
        margin-top: 250px; 
        margin: 50px;
        cursor: pointer;
        transition: .4s;
    }
   
   .bar:hover{
    background-color: white;
   }

    .slider{
        display: flex;
        width: 500%;
        height: 100%;
    }

    .slide{
        width: 20%;
        transition: .6s;
    }

    .slide img{
        height: 100%;
        width: 100%;   
    }

    .radio1:checked ~ .b1{
        background-color: whitesmoke;
    }

    .radio2:checked ~ .b2{
        background-color: whitesmoke;
    }

    .radio3:checked ~ .b3{
        background-color: whitesmoke;
    }

    #radio1:checked ~ .s1{
        margin-left: 0px;
    }

    #radio2:checked ~ .s1 {
        margin-left: -20%;
    }

    #radio3:checked ~ .s1 {
        margin-left: -40%;
    }

    .description{
        border-top-left-radius: 20px;
        border-top-right-radius: 20px;
        position: relative;
        margin-top: -75px;
        padding: 0px;
    }

    .description .banner{
        position: relative;
        overflow: hidden;
        width: 100%;
        height: 100%;
        margin: 0px;
        padding: 0px;
    }

    .description .bannerimg{
        position: relative;
        overflow: hidden;
        width: 100%;
        height: 60%;
        margin: 0px;
        padding: 0px;
    }

    .description .description-inside{
        position: absolute;
        overflow: hidden;
        width: 100%;
        height: 100%;
        margin-top: -5%;
        margin-left: 10%;
        padding: 0px;
    }

    .description .description-inside-sub{
        position: absolute;
        overflow: hidden;
        width: 100%;
        height: 100%;
        margin-top: 12.5%;
        margin-left: 10%;
        padding: 0px;
    }

    .description .description-inside-subber{
        position: absolute;
        overflow: hidden;
        width: 85%;
        height: 100%;
        margin-top: 25%;
        margin-left: 10%;
        padding: 0px;
    }

    .description .description-inside-btn{
        position: absolute;
        overflow: hidden;
        width: 250px;
        height: 38px;
        margin-top: -10%;
        margin-left: 10%;
        padding: 0px;
    }
    
    .about{
        background: url('img/about.png');
        background-size: 100%;
        background-position: center;
        background-repeat: no-repeat;
    }

    .about_two{
        background: url('img/about2.png');
        background-size: 100%;
        background-position: center;
        background-repeat: no-repeat;
    }

</style>

<script>

    var radio = document.querySelector('.bar')
    var count = 1

    document.getElementById('radio1').checked = true

    setInterval(() => {
        nextImg()
    }, 7500)

    function nextImg(){
        count++ 

        if(count > 3){
            count = 1
        }

        document.getElementById('radio'+count).checked = true
    }

    /* Collapsible */
    var elemsColap = document.querySelectorAll('.collapsible');
    var instancesColap = M.Collapsible.init(elemsColap);

</script><?php /**PATH C:\laragon\www\speb\resources\views/layout.blade.php ENDPATH**/ ?>