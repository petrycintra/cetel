

<div class="preloader valign-wrapper" id="preloader">
  <div class="progress">
    <div class="indeterminate"></div>
  </div>
</div>

<?php $__currentLoopData = $index; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dados): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<nav class="blue darken-4 hide-on-med-and-down">
    <div class="nav-wrapper container">
      <ul id="nav-mobile" class="left">
        <li><span class="email_phone"><i class="material-icons left">alternate_email</i> <?php echo e($dados->email); ?> </span></li>
        <li><span><i class="material-icons left">phone</i> <?php echo e($dados->tel_one); ?> | <?php echo e($dados->tel_two); ?> </span></li>
      </ul>

      <ul id="nav-mobile" class="right">
        <li><a href="<?php echo e(Route('cursopresencial')); ?>"> <i class="material-icons left"> school </i> <?php echo e($dados->menu_one); ?> </a></li>
        <?php if(auth()->guard()->check()): ?>
        <li><a href="<?php echo e(Route('dashboard')); ?>" class="orange darken-3 valign-wrapper"> <i class="material-icons left"> dashboard </i> Minha Dashboard </a></li>
        <?php else: ?>
        <li><a href="<?php echo e(Route('login.form')); ?>" class="orange darken-3 valign-wrapper"> <i class="material-icons left"> login </i> <?php echo e($dados->menu_btn); ?> </a></li>
        <?php endif; ?>
      </ul>
      </div>
</nav>

<nav class="white hide-on-med-and-down">
    <div class="nav-wrapper container">
        <img href="<?php echo e(Route('index')); ?>" class="left brand-logo" id="logo" src="/img/logo-index.png">
      <ul id="nav-mobile" class="right">
        <li ><a class="black-text" href="<?php echo e(Route('index')); ?>"> <?php echo e($dados->submenu_one); ?> </a></li>
        <li><a class="black-text" href="/#about"> <?php echo e($dados->submenu_two); ?> </a></li>
        <li ><a class="black-text" href="<?php echo e(Route('corpodocente')); ?>"> <?php echo e($dados->submenu_three); ?> </a></li>
        <li><a class="black-text" href="/#faq"> <?php echo e($dados->submenu_four); ?> </a></li>
        <li><a class="black-text" href="#"> <?php echo e($dados->submenu_five); ?> </a></li>
      </ul>
      </div>
</nav>

<nav class="blue darken-4 hide-on-large-only center">
  <div class="nav-wrapper container menu-mobile">
    <ul id="nav-mobile" class="center">
      <li ><a class="black-text" href="<?php echo e(Route('index')); ?>"> <i class="material-icons center"> home </i> </a></li>
      <li><a class="black-text" href="#about"> <i class="material-icons center"> apartment </i> </a></li>
      <li ><a class="black-text" href="<?php echo e(Route('corpodocente')); ?>"> <i class="material-icons center"> group </i> </a></li>
      <li><a class="black-text" href="#faq"> <i class="material-icons center"> help </i> </a></li>
      <li><a class="black-text" href=""> <i class="material-icons center"> contact_mail </i> </a></li>
      <?php if(auth()->guard()->check()): ?>
        <li><a class="black-text orange darken-3" href="<?php echo e(Route('dashboard')); ?>"> <i class="material-icons center"> dashboard </i> </a></li>
      <?php else: ?>
        <li><a class="black-text orange darken-3" href="<?php echo e(Route('login.form')); ?>"> <i class="material-icons center"> login </i> </a></li>
      <?php endif; ?>
    </ul>
    </div>
</nav>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php /**PATH C:\laragon\www\cetel\resources\views/navbar_index.blade.php ENDPATH**/ ?>