<nav class="pink lighten-2">
    <div class="nav-wrapper container">
        <a href="#" class="center brand-logo">Nutrios</a>
      <ul id="nav-mobile" class="left">
        <li><a href="#" data-target="slide-out" class="sidenav-trigger left show-on-large"><i class="material-icons">menu</i></a></li>
      </div>
</nav><?php /**PATH C:\laragon\www\Nutrios\resources\views/navbar.blade.php ENDPATH**/ ?>