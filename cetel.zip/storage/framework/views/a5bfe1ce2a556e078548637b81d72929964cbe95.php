
                                              <!-- Importar configurações do Framework Front-End Materialize.Css -->
<?php $__env->startSection('title', 'CETEL - Centro de Estudos Teológicos Logos'); ?> <!-- Titulo da Página -->
<?php $__env->startSection('body'); ?>                                                <!-- Inicia a seção d conteúdo da página -->
                                              <!-- Importar configurações do menu superior -->

<?php $__currentLoopData = $index; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dados): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<?php 
    //Cria array com caracteres não númericos  //Pega os caracteres informados e substitui por ""       //Transforma a variável String em int
    $remove = array('(', ')', ' ', '-');        $wnumber = str_replace($remove, '', $dados->tel_one);   $wnumber = intval($wnumber);
    $whats = "https://api.whatsapp.com/send/?phone=$wnumber&text=Olá%21+Gostaria+de+fazer+meu+cadastro+no+curso+de+psicanálise+&type=phone_number&app_absent=0";
?>

<div class="content">
    <div class="slider">

        <input class="radio-btn" type="radio" class="radio-slider" name="radio-slider" id="radio1">

        <div class="slide s1">
            <img src="/img/slide/<?php echo e($dados->slider_photo_two); ?>">
        </div>

    </div>

</div>

<div class="row white container description description-upside s12">

        <div class="row container">

            <div class="col s12 card brown lighten-4" id="title1">
                <div class="card-content"  href="#">
                    <span class="card-title orange-text center col s12"> <strong>CURSO PRESENCIAL</strong> </span>
                    
                    <div class="col s12 center">
                        <br>
                        <div class="col m6 s12">
                            <h6><i class="material-icons left"> schedule </i> <strong> Duração </strong><br>2 Anos</h6>
                        </div>

                        <div class="col m6 s12">
                            <h6><i class="material-icons left"> update </i> <strong> Carga Horária </strong><br>1.680 Horas</h6>
                        </div>
                    </div>

                    <div class="col s12 center">
                        <div class="col s12">
                            <br><br>
                            <a class="btn brown lighten-2 dashboard-buttons hide-on-med-and-down" href="<?php echo e($whats); ?>"> <i class="material-icons left"></i> QUERO ME MATRICULAR </a>
                            <a class="btn brown lighten-2 hide-on-large-only"
                            href="<?php echo e($whats); ?>">
                            <i class="material-icons left"></i> QUERO ME MATRICULAR </a>
                            <br><br>
                        </div>
                    </div>
                    
                </div>
            </div><br>
        </div>

            <?php $__currentLoopData = $cursopresencial; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dadoscurso): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <div class="row container">

            <div class="col m12 s12">
                <h5 class="col s12 orange-text darken-3" id="question"><strong> <?php echo e($dadoscurso->question); ?> <a href="<?php echo e(Route('cursopresencialedit')); ?>_<?php echo e($dadoscurso->id); ?>" class="btn orange darken-3 center col s4 right"> <i class="material-icons left"> edit </i>EDITAR </a> </h5>
                <br>
            </div><br>

            <div class="col m12 s12 corpodocente-paragraph">
                <span class="col s12" id="description-question"><strong> <?php echo e($dadoscurso->description); ?> </span>
            </div><br>
            
            

        </div>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><div class="row container">

            <div class="col m12 s12">
                <h5 class="col s12 orange-text darken-3" id="question"><strong> Grade Curricular </h5>
            </div><br><br><br>

            <div class="white">
                <ul class="collapsible">
                    <?php $__currentLoopData = $gradecurricular; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dadosgrade): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        
                    <li>
                        <div class="collapsible-header"><i class="material-icons">expand_more</i> <?php echo e($dadosgrade->title); ?>   <a href="<?php echo e(Route('gradecurricularedit')); ?>_<?php echo e($dadosgrade->id); ?>" class="btn orange darken-3 center col s4"> <i class="material-icons left"> edit </i>EDITAR </a></div>
                        <div class="collapsible-body"><span><?php echo e($dadosgrade->description); ?></span></div>
                    </li>
        
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>

        </div>
    </div>
        
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<a class="back-to-top btn orange darken-3" onclick="scrollToTop()" href="#"> <i class="material-icons center"> expand_less </i> </a>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\cetel\resources\views/admin/cursopresencialedit.blade.php ENDPATH**/ ?>