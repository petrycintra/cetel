<footer class="blue darken-4 page-footer">
    <div class="footer-copyright">
      <div class="container">
      © 2023 SPEB - Sociedade de Psicanálise Evolutiva do Brasil
      <font class="right">Site Desenvolvido por: <a class="grey-text text-lighten-4" href="#!"> Cintra Software</a> </font>
      
      </div>
    </div>
  </footer>
  <?php /**PATH C:\laragon\www\speb\resources\views/footer.blade.php ENDPATH**/ ?>