<nav class="blue darken-4 hide-on-med-and-down">
    <div class="nav-wrapper container">
      <ul id="nav-mobile" class="left">
        <li>
            <div class="input-field col s6">
                <input class="white-text" value="seucontato@dominio.com" id="first_name2" type="text" class="validate">
                <label class="active" for="first_name2"><i class="material-icons left">alternate_email</i></label>
            </div>
        </li>
        <li>
            <div class="input-field col s6">
                <input class="white-text" value="(73) 9 8888-8888" id="first_name2" type="text" class="validate">
                <label class="active" for="first_name2"><i class="material-icons left">phone</i></label>
            </div> |
        </li>
        <li>
            <div class="input-field col s6">
                <input class="white-text" value="(73) 9 8888-8888" id="first_name2" type="text" class="validate">
                <label class="active" for="first_name2"><i class="material-icons left">phone</i></label>
            </div>
        </li>
      </ul>

      <ul id="nav-mobile" class="right">
        <li><a href=""> Curso Presencial </a></li>
        <li><a href="<?php echo e(Route('login.form')); ?>" class="orange  valign-wrapper"> Acesso do Aluno </a></li>
      </ul>
      </div>
</nav>

<nav class="white hide-on-med-and-down">
    <div class="nav-wrapper container">
        <img href="#" class="left brand-logo" id="logo" src="/img/logo-index.png">
      <ul id="nav-mobile" class="right">
        <li ><a class="black-text" href=""> Inicio </a></li>
        <li><a class="black-text" href=""> Quem Somos </a></li>
        <li ><a class="black-text" href=""> Docentes </a></li>
        <li><a class="black-text" href=""> FAQ </a></li>
        <li><a class="black-text" href=""> Contato </a></li>
      </ul>
      </div>
</nav>

<nav class="blue darken-4 hide-on-large-only">
  <div class="nav-wrapper container">
      <img href="#" class="left brand-logo" id="logo" src="/img/logo.png">
    <ul id="nav-mobile" class="right">
      <li><a href="#" data-target="slide-out-mobile" class="sidenav-trigger right hide-on-large-onyl"><i class="material-icons left">menu</i></a></li>
    </ul>
    </div>
</nav>
<?php /**PATH C:\laragon\www\speb\resources\views/navbar_index_editable.blade.php ENDPATH**/ ?>