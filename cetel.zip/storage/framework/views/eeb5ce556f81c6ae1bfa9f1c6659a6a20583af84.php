
                                              <!-- Importar configurações do Framework Front-End Materialize.Css -->
<?php $__env->startSection('title', 'CETEL - Centro de Estudos Teológicos Logos'); ?> <!-- Titulo da Página -->
<?php $__env->startSection('body'); ?>                                                <!-- Inicia a seção d conteúdo da página -->
                                              <!-- Importar configurações do menu superior -->

<?php $__currentLoopData = $index; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dados): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<div class="content">
    <div class="slider">

        <input class="radio-btn" type="radio" class="radio-slider" name="radio-slider" id="radio1">

        <div class="slide s1">
            <img src="/img/slide/<?php echo e($dados->slider_photo_three); ?>">
        </div>

    </div>

</div>

<div class="row white container description-upside description s12">

        <div class="row container">

            <div class="card" id="title1">
                <div class="card-content"  href="#">
                    <span class="card-title orange-text center"> <strong>CORPO DOCENTE</strong> </span>
                </div>
            </div><br>
        </div>

            <?php $__currentLoopData = $corpodocente; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dadosdocente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <div class="row container">

            <div class="col m4 s12 center photo-name">
                <img class="perfil-photo" src="./img/corpodocente/<?php echo e($dadosdocente->perfil_photo); ?>" >
                <h6 class="col s12 grey-text darken-2" id="office"><strong> <?php echo e($dadosdocente->office); ?> </strong></h6>
                <h5 class="col s12 blue-text darken-5 name-surname" id="name_surname"> <strong><?php echo e($dadosdocente->name); ?></strong> <?php echo e($dadosdocente->surname); ?></h5>
            </div>

            <div class="col m8 s12 corpodocente-paragraph">
                <h6>
                    <?php echo e($dadosdocente->paragraph_one); ?>

                </h6>

                <h6>
                    <?php echo e($dadosdocente->paragraph_two); ?>

                </h6>

                <h6>
                    <?php echo e($dadosdocente->paragraph_three); ?>

                </h6>
            </div>
            <hr>

        </div>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
        
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<a class="back-to-top btn orange darken-3" onclick="scrollToTop()" href="#"> <i class="material-icons center"> expand_less </i> </a>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\cetel\resources\views/corpodocente.blade.php ENDPATH**/ ?>