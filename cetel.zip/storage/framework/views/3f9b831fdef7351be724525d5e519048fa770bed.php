                                  <!-- Importar configurações do Framework Front-End Materialize.Css -->
<?php $__env->startSection('title', 'Cadastro de nova receita -  Nutrios'); ?>  <!-- Titulo da Página -->
<?php $__env->startSection('body'); ?>                                    <!-- Inicia a seção d conteúdo da página -->


<div class="row container">
        <div class="row center">
            <div class="col s12 m12">
                <div class="card pink lighten-5">
                    <div class="card-content text">

                            <span class="card-title"><strong>CADASTRAR RECEITA</strong></span><br>

                    </div>
                </div>
            </div>
        </div>

        <form action="">

        <div class="col s12 m12">
            <div class="card pink lighten-5">
                <div class="card-content text">

                    <div>
                        <div class="input-field col s12 m6 ">
                            <input id="title" placeholder="Qual o titulo da receita?" type="text" class="validate" data-length="20" required >
                            <label class="active" for="title"><i class="material-icons left">title</i> Titulo <font color="red"> * </font></label>
                        </div>
                    </div>

                    <div>
                        <div class="input-field col s12 m6 ">
                            <input id="description" placeholder="Insira uma breve descrição da receita" type="text" class="validate">
                            <label class="active" for="title"><i class="material-icons left">brush</i> Descrição </label>
                        </div>
                    </div>

                    <div>
                        <div class="input-field col s12 m12 ">
                            <input id="ingredients" placeholder="Insira os ingredientes" type="text" class="validate">
                            <label class="active" for="title"><i class="material-icons left">brush</i> Ingredientes (Separados por virgula) <font color="red"> * </font></label>
                            <font color="grey"> Exemplo: Cenoura, Maçã, Abacaxi </font>
                        </div><br><br>
                    </div>

                        <a class="waves-effect waves-teal btn-flat"> </a> <!-- Não remover essa linha -->

                </div>
            </div>
        </div>

        <div class="row center">
            <div class="col s12 m12">
                <div class="card pink lighten-5">
                    <div class="card-content text">

                            <span class="card-title"><strong>PASSO A PASSO</strong></span><br>

                    </div>
                </div>
            </div>
        </div>

        <div class="col s12 m12">
            <div class="card pink lighten-5">
                <div class="card-content text">

                    <div class="row">
                        <div class="input-field col s12 m12">
                          <textarea id="step_by_step" placeholder="Qual passo a passo da receita?" class="materialize-textarea" data-length="120"></textarea>
                          <label class="active" for="step_by_step"><i class="material-icons left">title</i> Descreva abaixo, com detalhes, o passo a passo. <font color="red"> * </font></label>
                        </div>
                    </div>

                </div>
            </div>
        </div>

        <div class="col s12 m12">
            <div class="card pink lighten-5">
                <div class="card-content text">
                        
                    <div class="center">
                        <a type="submit" class="btn pink lighten-2 "> CADASTRAR </a>
                        <a href="" class="btn orange lighten-2"> CANCELAR </a><br><br>
                    </div>

                </div>
            </div>
        </div>

    </form>

    </div>
    </div>
</div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('nav-and-sidebar'); ?>                         <!-- Inicia o seção de menu superior e lateral da página -->
                                  <!-- Importar configurações do menu superior -->
<?php $__env->stopSection(); ?>                                         <!-- Encerra a seção de menu superior e lateral da página -->


<?php echo $__env->make('navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Nutrios\resources\views/restrito/cad_edit/cad_receita.blade.php ENDPATH**/ ?>